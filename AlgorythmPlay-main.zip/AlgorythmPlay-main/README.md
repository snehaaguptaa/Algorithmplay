AlgorythmPlay: A web application crafted with HTML, CSS, and
JavaScript, offering interactive visualization and gaming experiences for
various algorithms, including sorting, N-Queens, and Sudoku.

